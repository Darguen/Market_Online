

Descripcion del proyecto:

Se requiere realizar una aplicación movil que permita a los usuarios realizar el registro de mercaderia(comida, articulos de aseo, etc), para mantener un registro
completo de lo que ya se tiene comprado y lo que falta por comprar.

Por esto se pide que la aplicación le permita al usuario poder guardar los productos, gestionar los productos, ver los precios asociados y editarlos en caso de ser
necesario.
Todo lo antes mencionado se necesita mediante el uso de interfaces interactivas en pantallas tales como, la lista de productos, y la lista o historial de movimientos
realizados.

Link repositorio:https://github.com/Darguen/Market_Online

Link: https://drive.google.com/file/d/16dAxVp9E0uU3VcHncNk-43qmMoBbMs35/view?usp=sharing
