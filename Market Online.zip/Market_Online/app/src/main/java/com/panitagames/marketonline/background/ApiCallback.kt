package com.panitagames.marketonline.background

interface ApiCallback {
    fun onRequestComplete(result: String)
}